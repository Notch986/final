function y=duffing(t,x,v,c,b,d,f,w)
  y=b*x-x^3-c*v+f*cos(w*t);

