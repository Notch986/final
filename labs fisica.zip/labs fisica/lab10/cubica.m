function y=cubica(x)
  y=x-x^3;

