function a = duffing_subamortiguado(t, x, v, c, b, d, f, w)
    a = -x - c * v;
end
