function y = armonico_simple(x,omega,c,v)
    y = -omega^2*x - c*v;
