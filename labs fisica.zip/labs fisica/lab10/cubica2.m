function y=cubica2(x,c,v)
  y=x-x^3-c*v;

