function y = trespoincare(t, x, v, c, b, d, f, w)
    y = -x;
end
