function a=ay(x,y)
  a=-y/(x^2+y^2)^(3/2);