function a=ax(x,y)
  a=-x/(x^2+y^2)^(3/2);